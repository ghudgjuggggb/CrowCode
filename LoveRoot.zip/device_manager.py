"""
device_manager.py — LoveRoot core logic

Wraps calls to `adb` and `fastboot` (expected to be bundled in ./platform-tools
or available on PATH) to:
  1. Detect a connected Android device (ADB or Fastboot mode)
  2. Reboot it into bootloader/fastboot mode
  3. Flash a user-supplied, pre-patched boot image to the `boot` partition
  4. Reboot and verify root access via `su`

IMPORTANT — scope and limits of this tool:
  * This does NOT create, patch, or generate boot images. The user must supply
    an already-patched boot.img (e.g. produced with Magisk's "Patch Boot Image"
    feature on their own device) for their exact device/firmware. Flashing the
    wrong image can hard-brick a device — there is no way to make that generically
    safe, so this tool refuses to guess and instead requires an explicit,
    user-selected file.
  * This does NOT unlock bootloaders or bypass OEM locks. `fastboot flashing
    unlock` typically wipes user data and is something the user must invoke
    themselves, consciously, after reading their OEM's specific warnings.
  * This does NOT silently install kernel-mode drivers. On Windows, driver
    installation is delegated to `pnputil`, which requires the user to accept
    a UAC elevation prompt — there's no path around that, by design.
"""

from __future__ import annotations

import os
import platform
import shutil
import subprocess
import time
from dataclasses import dataclass
from typing import Optional


def _tool_path(name: str) -> str:
    """Resolve adb/fastboot: prefer a bundled copy in ./platform-tools, else PATH."""
    exe = name + (".exe" if platform.system() == "Windows" else "")
    local = os.path.join(os.path.dirname(os.path.abspath(__file__)), "platform-tools", exe)
    if os.path.isfile(local):
        return local
    found = shutil.which(exe)
    if found:
        return found
    raise FileNotFoundError(
        f"'{exe}' not found in ./platform-tools or PATH. "
        f"Install Android platform-tools first."
    )


def _run(cmd: list[str], timeout: int = 30) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)


@dataclass
class DeviceInfo:
    serial: str
    mode: str  # "adb" or "fastboot"
    model: Optional[str] = None


class LoveRootError(RuntimeError):
    pass


class DeviceManager:
    def __init__(self, log=print):
        self.log = log
        self.adb = _tool_path("adb")
        self.fastboot = _tool_path("fastboot")

    # ---------- Detection ----------

    def detect_device(self) -> DeviceInfo:
        """Look for a device in ADB mode first, then Fastboot mode."""
        adb_out = _run([self.adb, "devices"]).stdout.strip().splitlines()
        for line in adb_out[1:]:
            if line.strip() and "\tdevice" in line:
                serial = line.split("\t")[0]
                model = self._get_prop(serial, "ro.product.model")
                self.log(f"Found ADB device: {serial} ({model})")
                return DeviceInfo(serial=serial, mode="adb", model=model)

        fb_out = _run([self.fastboot, "devices"]).stdout.strip().splitlines()
        for line in fb_out:
            if line.strip():
                serial = line.split("\t")[0]
                self.log(f"Found Fastboot device: {serial}")
                return DeviceInfo(serial=serial, mode="fastboot", model=None)

        raise LoveRootError(
            "No device found. Check that USB debugging is enabled, the phone "
            "is unlocked and you've accepted the 'Allow USB debugging' prompt, "
            "or that it's already sitting in fastboot mode."
        )

    def _get_prop(self, serial: str, prop: str) -> str:
        result = _run([self.adb, "-s", serial, "shell", "getprop", prop])
        return result.stdout.strip() or "unknown"

    # ---------- Driver install (Windows only) ----------

    def install_driver(self, inf_path: str) -> None:
        """
        Installs a Windows USB driver via pnputil. This WILL trigger a UAC
        elevation prompt — intentionally, since silent driver installation
        without user consent is not something this tool will do.
        """
        if platform.system() != "Windows":
            self.log("Driver install skipped (not on Windows).")
            return
        if not os.path.isfile(inf_path):
            raise LoveRootError(f"Driver .inf not found: {inf_path}")

        self.log(f"Requesting elevated driver install for {inf_path} ...")
        result = subprocess.run(
            ["powershell", "-Command",
             f"Start-Process pnputil -ArgumentList '/add-driver \"{inf_path}\" /install' -Verb RunAs -Wait"],
            capture_output=True, text=True,
        )
        if result.returncode != 0:
            raise LoveRootError(f"Driver install failed: {result.stderr.strip()}")
        self.log("Driver installed.")

    # ---------- Flashing ----------

    def reboot_to_bootloader(self, device: DeviceInfo) -> None:
        if device.mode == "fastboot":
            return
        self.log("Rebooting to bootloader...")
        _run([self.adb, "-s", device.serial, "reboot", "bootloader"])
        self._wait_for_fastboot()

    def _wait_for_fastboot(self, timeout: int = 30) -> str:
        deadline = time.time() + timeout
        while time.time() < deadline:
            out = _run([self.fastboot, "devices"]).stdout.strip()
            if out:
                return out.split("\t")[0]
            time.sleep(1)
        raise LoveRootError("Timed out waiting for device to enter fastboot mode.")

    def flash_boot_image(self, boot_img_path: str) -> None:
        if not os.path.isfile(boot_img_path):
            raise LoveRootError(f"Boot image not found: {boot_img_path}")

        self.log(f"Flashing {os.path.basename(boot_img_path)} to 'boot' partition...")
        result = _run([self.fastboot, "flash", "boot", boot_img_path], timeout=180)
        if result.returncode != 0:
            raise LoveRootError(f"Flash failed:\n{result.stderr.strip()}")
        self.log("Flash completed successfully.")

    def reboot_device(self) -> None:
        self.log("Rebooting device...")
        _run([self.fastboot, "reboot"])

    # ---------- Verification ----------

    def verify_root(self, serial: str, timeout: int = 60) -> bool:
        """Poll for the device to come back online, then check for `su`."""
        self.log("Waiting for device to boot back up (this can take a minute)...")
        deadline = time.time() + timeout
        online = False
        while time.time() < deadline:
            out = _run([self.adb, "devices"]).stdout
            if "device" in out and serial in out:
                online = True
                break
            time.sleep(2)
        if not online:
            raise LoveRootError("Device did not come back online in time.")

        result = _run([self.adb, "-s", serial, "shell", "su", "-c", "id"])
        has_root = "uid=0" in result.stdout
        self.log("Root check: " + ("SUCCESS" if has_root else "NOT DETECTED"))
        return has_root
