"""
device_manager.py — LoveRoot core logic

Wraps calls to `adb` and `fastboot` (expected to be bundled in ./platform-tools
or available on PATH) to:
  1. Detect a connected Android device (ADB or Fastboot mode)
  2. Reboot it into bootloader/fastboot mode
  3. Flash a user-supplied, pre-patched boot image to the `boot` partition
  4. Reboot and verify root access via `su`

IMPORTANT — scope and limits of this tool:
  * This does NOT create, patch, or generate boot images. The user must supply
    an already-patched boot.img (e.g. produced with Magisk's "Patch Boot Image"
    feature on their own device) for their exact device/firmware. Flashing the
    wrong image can hard-brick a device — there is no way to make that generically
    safe, so this tool refuses to guess and instead requires an explicit,
    user-selected file.
  * This does NOT unlock bootloaders or bypass OEM locks. `fastboot flashing
    unlock` typically wipes user data and is something the user must invoke
    themselves, consciously, after reading their OEM's specific warnings.
  * This does NOT silently install kernel-mode drivers. On Windows, driver
    installation is delegated to `pnputil`, which requires the user to accept
    a UAC elevation prompt — there's no path around that, by design.
"""

from __future__ import annotations

import os
import platform
import shutil
import subprocess
import time
from dataclasses import dataclass
from typing import Optional


def _tool_path(name: str) -> str:
    """Resolve adb/fastboot: prefer a bundled copy in ./platform-tools, else PATH."""
    exe = name + (".exe" if platform.system() == "Windows" else "")
    local = os.path.join(os.path.dirname(os.path.abspath(__file__)), "platform-tools", exe)
    if os.path.isfile(local):
        return local
    found = shutil.which(exe)
    if found:
        return found
    raise FileNotFoundError(
        f"'{exe}' not found in ./platform-tools or PATH. "
        f"Install Android platform-tools first."
    )


def _run(cmd: list[str], timeout: int = 30) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)


@dataclass
class DeviceInfo:
    serial: str
    mode: str  # "adb" or "fastboot"
    model: Optional[str] = None


class LoveRootError(RuntimeError):
    pass


def install_driver_standalone(inf_path: str, log=print) -> None:
    """
    Installs a Windows USB driver via pnputil. Deliberately NOT a method on
    DeviceManager: constructing a DeviceManager requires adb/fastboot to
    already be resolved, but driver install is exactly the kind of thing
    you need to do WHILE adb/fastboot still aren't working — so this must
    be callable on its own.

    Triggers a UAC elevation prompt intentionally — silent driver install
    without user consent is not something this tool will do.

    Since pnputil runs in a separate elevated process (via
    Start-Process -Verb RunAs), its own stdout/stderr aren't piped back to
    us directly — we redirect them to temp files and read those back so
    real pnputil errors (e.g. "driver not signed") actually surface
    instead of being silently swallowed.
    """
    if platform.system() != "Windows":
        log("Driver install skipped (not on Windows).")
        return
    if not os.path.isfile(inf_path):
        raise LoveRootError(f"Driver .inf not found: {inf_path}")

    log(f"Requesting elevated driver install for {inf_path} ...")
    out_file = os.path.join(os.environ.get("TEMP", "."), "loveroot_pnputil_out.txt")
    err_file = os.path.join(os.environ.get("TEMP", "."), "loveroot_pnputil_err.txt")
    for f in (out_file, err_file):
        if os.path.exists(f):
            os.remove(f)

    ps_cmd = (
        f"$p = Start-Process pnputil -ArgumentList '/add-driver \"{inf_path}\" /install' "
        f"-Verb RunAs -Wait -PassThru "
        f"-RedirectStandardOutput '{out_file}' -RedirectStandardError '{err_file}'; "
        f"exit $p.ExitCode"
    )
    result = subprocess.run(["powershell", "-Command", ps_cmd], capture_output=True, text=True)

    pnputil_out = ""
    for f in (out_file, err_file):
        if os.path.isfile(f):
            with open(f, "r", errors="ignore") as fh:
                pnputil_out += fh.read()

    if pnputil_out.strip():
        log(pnputil_out.strip())

    if result.returncode != 0:
        msg = pnputil_out.strip() or result.stderr.strip() or f"pnputil exited with code {result.returncode}"
        if "sign" in msg.lower() or "catalog" in msg.lower():
            msg += (
                "\n\nThis looks like a driver signature issue — Windows blocks unsigned "
                "drivers by default. Either temporarily disable Driver Signature "
                "Enforcement (Windows Advanced Startup) or use Zadig (zadig.akeo.ie) "
                "instead, which installs the same kind of driver but properly signed."
            )
        raise LoveRootError(f"Driver install failed: {msg}")
    log("Driver installed.")


def diagnose(log=print) -> str:
    """
    Print a raw diagnostic dump: whether adb/fastboot exist, and if so,
    the raw output of `adb devices` and `fastboot devices`. Doesn't require
    a DeviceManager instance, so it works even when tools are missing.
    """
    lines = []
    for name in ("adb", "fastboot"):
        try:
            path = _tool_path(name)
            lines.append(f"{name}: found at {path}")
        except FileNotFoundError as e:
            lines.append(f"{name}: NOT FOUND ({e})")

    for name in ("adb", "fastboot"):
        try:
            path = _tool_path(name)
            result = _run([path, "devices"], timeout=15)
            lines.append(f"\n$ {name} devices\n{result.stdout.strip() or '(empty output)'}"
                         + (f"\nstderr: {result.stderr.strip()}" if result.stderr.strip() else ""))
        except FileNotFoundError:
            lines.append(f"\n$ {name} devices\n(skipped — {name} not found)")
        except Exception as e:
            lines.append(f"\n$ {name} devices\nERROR: {e}")

    report = "\n".join(lines)
    log(report)
    return report


class DeviceManager:
    def __init__(self, log=print):
        self.log = log
        self.adb = _tool_path("adb")
        self.fastboot = _tool_path("fastboot")

    # ---------- Bootloader unlock helpers ----------
    #
    # IMPORTANT — what this section can and can't do:
    # Xiaomi (and most other OEMs) do NOT allow bootloader unlock via a
    # plain fastboot command. It requires their own signed tool (Mi Unlock)
    # talking to Xiaomi's authentication servers, tied to a logged-in Mi
    # account, usually with a mandatory waiting period. There is no local
    # command or file we can send that replicates that server-side
    # approval — so this tool can check status and open the official page,
    # but the actual unlock has to happen through Xiaomi's own app.

    OFFICIAL_MI_UNLOCK_URL = "https://en.miui.com/unlock/index.html"

    def check_oem_unlock_toggle(self, serial: str) -> Optional[bool]:
        """
        Check whether 'OEM unlocking' is enabled in Developer Options.
        Returns True/False, or None if it couldn't be determined (e.g. on
        very old Android versions this setting doesn't exist).
        """
        result = _run([self.adb, "-s", serial, "shell", "settings", "get", "global", "oem_unlock_allowed"])
        val = result.stdout.strip()
        if val == "1":
            return True
        if val == "0":
            return False
        return None

    def check_bootloader_state(self, device: DeviceInfo) -> str:
        """
        Query fastboot for the current bootloader lock state.
        Returns 'yes' (unlocked), 'no' (locked), or 'unknown'.
        """
        if device.mode != "fastboot":
            raise LoveRootError("Device must be in fastboot mode to check unlock state.")
        result = _run([self.fastboot, "-s", device.serial, "getvar", "unlocked"], timeout=15)
        combined = (result.stdout + result.stderr).lower()
        if "unlocked: yes" in combined:
            return "yes"
        if "unlocked: no" in combined:
            return "no"
        return "unknown"

    def try_fastboot_unlock(self, device: DeviceInfo) -> str:
        """
        Attempt the generic `fastboot flashing unlock` command. On Xiaomi
        devices this will almost always be refused (they disable this path
        entirely in favor of Mi Unlock) — but it costs nothing to try, and
        on some other OEMs/devices it's all that's needed. Returns the raw
        fastboot output so the caller can show the real reason if refused.
        """
        if device.mode != "fastboot":
            raise LoveRootError("Device must be in fastboot mode to attempt unlock.")
        result = _run([self.fastboot, "-s", device.serial, "flashing", "unlock"], timeout=30)
        output = (result.stdout + result.stderr).strip()
        if result.returncode != 0 or "not allowed" in output.lower() or "fail" in output.lower():
            raise LoveRootError(
                f"fastboot refused to unlock (expected on Xiaomi devices):\n{output}\n\n"
                f"Use the official Mi Unlock Tool instead — see {self.OFFICIAL_MI_UNLOCK_URL}"
            )
        return output

    # ---------- Detection ----------

    def detect_device(self) -> DeviceInfo:
        """Look for a device in ADB mode first, then Fastboot mode."""
        adb_out = _run([self.adb, "devices"]).stdout.strip().splitlines()
        for line in adb_out[1:]:
            if line.strip() and "\tdevice" in line:
                serial = line.split("\t")[0]
                model = self._get_prop(serial, "ro.product.model")
                self.log(f"Found ADB device: {serial} ({model})")
                return DeviceInfo(serial=serial, mode="adb", model=model)

        fb_out = _run([self.fastboot, "devices"]).stdout.strip().splitlines()
        for line in fb_out:
            if line.strip():
                serial = line.split("\t")[0]
                self.log(f"Found Fastboot device: {serial}")
                return DeviceInfo(serial=serial, mode="fastboot", model=None)

        raise LoveRootError(
            "No device found. Check that USB debugging is enabled, the phone "
            "is unlocked and you've accepted the 'Allow USB debugging' prompt, "
            "or that it's already sitting in fastboot mode."
        )

    def _get_prop(self, serial: str, prop: str) -> str:
        result = _run([self.adb, "-s", serial, "shell", "getprop", prop])
        return result.stdout.strip() or "unknown"

    # ---------- Driver install (Windows only) ----------

    def install_driver(self, inf_path: str) -> None:
        """Instance convenience wrapper — see install_driver_standalone() below."""
        install_driver_standalone(inf_path, log=self.log)

    # ---------- Flashing ----------

    def reboot_to_bootloader(self, device: DeviceInfo) -> str:
        if device.mode == "fastboot":
            return device.serial
        self.log("Rebooting to bootloader...")
        _run([self.adb, "-s", device.serial, "reboot", "bootloader"])
        return self._wait_for_fastboot()

    def _wait_for_fastboot(self, timeout: int = 30) -> str:
        deadline = time.time() + timeout
        while time.time() < deadline:
            out = _run([self.fastboot, "devices"]).stdout.strip()
            if out:
                return out.split("\t")[0]
            time.sleep(1)
        raise LoveRootError("Timed out waiting for device to enter fastboot mode.")

    def flash_boot_image(self, boot_img_path: str, partition: str = "boot") -> None:
        if not os.path.isfile(boot_img_path):
            raise LoveRootError(f"Boot image not found: {boot_img_path}")

        self.log(f"Flashing {os.path.basename(boot_img_path)} to '{partition}' partition...")
        result = _run([self.fastboot, "flash", partition, boot_img_path], timeout=180)
        if result.returncode != 0:
            raise LoveRootError(f"Flash failed:\n{result.stderr.strip()}")
        self.log("Flash completed successfully.")

    def reboot_device(self) -> None:
        self.log("Rebooting device...")
        _run([self.fastboot, "reboot"])

    # ---------- Experimental: pull a partition image straight off the device ----------

    def fetch_partition_experimental(self, device: DeviceInfo, partition: str, dest_path: str) -> None:
        """
        Try to read a partition (e.g. 'boot' or 'init_boot') directly off
        the device via `fastboot fetch`, which works through userspace
        fastboot (fastbootd) WITHOUT needing existing root.

        Caveats (real, not hedging): `fetch` is a relatively recent fastboot
        feature that's reliably supported on Pixel-class devices. Many other
        vendors' fastbootd implementations don't support it — especially on
        non-Qualcomm/non-Pixel SoCs (e.g. Unisoc). If it's unsupported,
        fastboot will just return an error here rather than damage anything.
        """
        self.log("Rebooting into userspace fastboot (fastbootd) to attempt fetch...")
        _run([self.fastboot, "-s", device.serial, "reboot", "fastboot"], timeout=30)

        # fastbootd re-enumerates as a fastboot device, same as bootloader fastboot.
        serial = self._wait_for_fastboot(timeout=30)

        self.log(f"Attempting to fetch '{partition}' partition...")
        result = _run([self.fastboot, "-s", serial, "fetch", partition, dest_path], timeout=120)
        if result.returncode != 0:
            raise LoveRootError(
                f"fastboot fetch failed — this device likely doesn't support reading "
                f"'{partition}' this way (common on non-Pixel devices).\n"
                f"{result.stderr.strip()}\n\n"
                f"Use 'Extract from firmware archive' instead, or extract boot.img via "
                f"the KernelSU/Magisk app AFTER you already have root."
            )
        self.log(f"Fetched '{partition}' to {dest_path}.")

    # ---------- Pull an already-patched file the user saved on the phone ----------

    def list_phone_downloads(self, serial: str) -> list[str]:
        """List files in the phone's Download folder, to help pick a patched image."""
        result = _run([self.adb, "-s", serial, "shell", "ls", "-1", "/sdcard/Download/"])
        if result.returncode != 0:
            raise LoveRootError(f"Could not list /sdcard/Download/: {result.stderr.strip()}")
        return [line.strip() for line in result.stdout.splitlines() if line.strip()]

    def pull_from_phone(self, serial: str, remote_path: str, local_dest: str) -> None:
        """adb pull a file (e.g. a Magisk/KernelSU-patched image) off the phone."""
        result = _run([self.adb, "-s", serial, "pull", remote_path, local_dest], timeout=120)
        if result.returncode != 0:
            raise LoveRootError(f"adb pull failed: {result.stderr.strip()}")
        self.log(f"Pulled {remote_path} -> {local_dest}")

    # ---------- Verification ----------

    def verify_root(self, serial: str, timeout: int = 60) -> bool:
        """Poll for the device to come back online, then check for `su`."""
        self.log("Waiting for device to boot back up (this can take a minute)...")
        deadline = time.time() + timeout
        online = False
        while time.time() < deadline:
            out = _run([self.adb, "devices"]).stdout
            if "device" in out and serial in out:
                online = True
                break
            time.sleep(2)
        if not online:
            raise LoveRootError("Device did not come back online in time.")

        result = _run([self.adb, "-s", serial, "shell", "su", "-c", "id"])
        has_root = "uid=0" in result.stdout
        self.log("Root check: " + ("SUCCESS" if has_root else "NOT DETECTED"))
        return has_root
