"""
firmware_tools.py — helpers for pulling boot.img / init_boot.img out of a
stock firmware package the user already downloaded, and for pulling an
already-patched image back off the phone via adb.

What this module deliberately does NOT do: patch boot images (inject
Magisk/KernelSU). That step is left to the Magisk/KernelSU app on the
device itself, which uses their own extensively tested magiskboot tooling.
Reimplementing that here would mean guessing at ramdisk/kernel repacking
logic without the same battle-testing — a real way to turn "automate a
convenience step" into "brick someone's phone". So this module only ever
moves already-complete files around; it never modifies their contents.
"""

from __future__ import annotations

import os
import shutil
import tarfile
import zipfile
from pathlib import Path
from typing import Optional

WANTED_NAMES = ("boot.img", "init_boot.img")


class FirmwareToolsError(RuntimeError):
    pass


def _is_tar(path: str) -> bool:
    return path.lower().endswith((".tgz", ".tar.gz", ".tar"))


def _is_zip(path: str) -> bool:
    return path.lower().endswith(".zip")


def extract_boot_images(archive_path: str, dest_dir: str, log=print) -> list[str]:
    """
    Open a stock firmware archive (.tgz/.tar.gz/.zip) and copy out any
    boot.img / init_boot.img it contains into dest_dir, WITHOUT modifying
    them. Returns the list of destination file paths found.

    Firmware archives are large (multi-GB); we stream-extract only the
    members we actually want instead of unpacking the whole thing.
    """
    if not os.path.isfile(archive_path):
        raise FirmwareToolsError(f"Archive not found: {archive_path}")
    os.makedirs(dest_dir, exist_ok=True)

    found: list[str] = []

    if _is_tar(archive_path):
        log(f"Scanning {os.path.basename(archive_path)} (tar) for boot images...")
        with tarfile.open(archive_path, "r:*") as tf:
            for member in tf:
                name = os.path.basename(member.name)
                if name in WANTED_NAMES:
                    log(f"Found {member.name} — extracting...")
                    src = tf.extractfile(member)
                    if src is None:
                        continue
                    dest_path = os.path.join(dest_dir, name)
                    with open(dest_path, "wb") as out:
                        shutil.copyfileobj(src, out)
                    found.append(dest_path)

    elif _is_zip(archive_path):
        log(f"Scanning {os.path.basename(archive_path)} (zip) for boot images...")
        with zipfile.ZipFile(archive_path, "r") as zf:
            for info in zf.infolist():
                name = os.path.basename(info.filename)
                if name in WANTED_NAMES:
                    log(f"Found {info.filename} — extracting...")
                    dest_path = os.path.join(dest_dir, name)
                    with zf.open(info) as src, open(dest_path, "wb") as out:
                        shutil.copyfileobj(src, out)
                    found.append(dest_path)
    else:
        raise FirmwareToolsError(
            "Unrecognized archive type — expected .tgz/.tar.gz or .zip. "
            "If your firmware download is some other format, extract it "
            "manually and use 'Select patched boot.img' once you've patched it."
        )

    if not found:
        raise FirmwareToolsError(
            "No boot.img or init_boot.img found inside this archive. "
            "Some firmware packages nest another archive inside (e.g. an "
            "images.zip) — you may need to extract that one first."
        )

    log(f"Extracted {len(found)} file(s) to {dest_dir}. "
        f"These are STOCK images — patch them in KernelSU/Magisk on your "
        f"phone before flashing.")
    return found
