"""
bootstrap.py — auto-installs Android platform-tools (adb + fastboot) if missing.

Downloads the OFFICIAL Google package for the current OS from
https://developer.android.com/tools/releases/platform-tools
(dl.google.com is Google's own distribution server for these tools).

This only runs if ./platform-tools/adb(.exe) and fastboot(.exe) are not
already present next to the app, and are not already available on PATH.
"""

from __future__ import annotations

import os
import platform
import shutil
import urllib.request
import zipfile
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
TOOLS_DIR = BASE_DIR / "platform-tools"

_URLS = {
    "Windows": "https://dl.google.com/android/repo/platform-tools-latest-windows.zip",
    "Linux": "https://dl.google.com/android/repo/platform-tools-latest-linux.zip",
    "Darwin": "https://dl.google.com/android/repo/platform-tools-latest-darwin.zip",
}


class BootstrapError(RuntimeError):
    pass


def _exe(name: str) -> str:
    return name + (".exe" if platform.system() == "Windows" else "")


USB_DRIVER_DIR = BASE_DIR / "usb_driver"
USB_DRIVER_URL = "https://dl.google.com/android/repository/usb_driver_r13-windows.zip"


def usb_driver_present() -> bool:
    """True if we've already downloaded the generic Google USB/fastboot driver."""
    return (USB_DRIVER_DIR / "android_winusb.inf").is_file()


def ensure_usb_driver(log=print, progress=None) -> "Path":
    """
    Download Google's official generic Android USB driver package (Windows
    only) — this is the android_winusb.inf that Windows needs to recognize
    a phone in fastboot mode, which otherwise has to be pointed to manually
    in Device Manager.

    Returns the path to the extracted android_winusb.inf file.

    Note: this generic driver covers Nexus/Pixel-class USB IDs out of the
    box. Some vendors (e.g. Xiaomi) ship their own fastboot driver that
    works more reliably — if installing this one doesn't fix detection,
    the user should install their phone maker's official driver instead.
    We only ever fetch this ONE official Google-hosted package here; we
    do not download or run third-party "driver fixer" tools.
    """
    if platform.system() != "Windows":
        raise BootstrapError("USB driver install is only applicable on Windows.")

    if usb_driver_present():
        log("USB driver already downloaded.")
        return USB_DRIVER_DIR / "android_winusb.inf"

    log("Downloading official Google USB driver (for fastboot-mode detection)...")
    USB_DRIVER_DIR.mkdir(parents=True, exist_ok=True)
    zip_path = BASE_DIR / "usb_driver.zip"

    def _reporthook(block_num, block_size, total_size):
        if progress and total_size > 0:
            progress(min(1.0, block_num * block_size / total_size))

    try:
        urllib.request.urlretrieve(USB_DRIVER_URL, zip_path, reporthook=_reporthook)
    except Exception as e:
        raise BootstrapError(
            f"Driver download failed ({e}). You can download it manually from "
            f"{USB_DRIVER_URL} and unzip it into '{USB_DRIVER_DIR}'."
        ) from e

    log("Download complete. Extracting driver...")
    try:
        extract_dir = BASE_DIR / "_usbdrv_extract_tmp"
        if extract_dir.exists():
            shutil.rmtree(extract_dir)
        with zipfile.ZipFile(zip_path, "r") as zf:
            zf.extractall(extract_dir)

        # The zip contains a top-level "usb_driver/" folder — merge into USB_DRIVER_DIR.
        found_root = None
        for candidate in extract_dir.rglob("android_winusb.inf"):
            found_root = candidate.parent
            break
        if not found_root:
            raise BootstrapError("android_winusb.inf not found inside the downloaded driver package.")

        USB_DRIVER_DIR.mkdir(parents=True, exist_ok=True)
        for item in found_root.iterdir():
            dest = USB_DRIVER_DIR / item.name
            if dest.exists():
                if dest.is_dir():
                    shutil.rmtree(dest)
                else:
                    dest.unlink()
            shutil.move(str(item), str(dest))
    finally:
        zip_path.unlink(missing_ok=True)
        if extract_dir.exists():
            shutil.rmtree(extract_dir, ignore_errors=True)

    if not usb_driver_present():
        raise BootstrapError(f"Driver extraction failed — check '{USB_DRIVER_DIR}' manually.")

    log("USB driver downloaded and ready to install.")
    return USB_DRIVER_DIR / "android_winusb.inf"


GENERIC_DRIVER_DIR = BASE_DIR / "generic_fastboot_driver"

# This INF matches ANY device presenting the standard Android fastboot USB
# interface (class FF, subclass 42, protocol 03) — the same interface class
# every vendor uses for fastboot, regardless of VID/PID. Unlike the
# vendor-specific Google USB Driver above, this isn't limited to
# Nexus/Pixel hardware IDs, so it also covers Xiaomi/Redmi/POCO and other
# brands whose fastboot mode isn't recognized by the generic Google package.
#
# NOTE: this .inf is unsigned. On Windows with Secure Boot / driver
# signature enforcement on (the default), pnputil may refuse to install it.
# If that happens, install_driver() will surface the signature error in the
# log, and the practical fallback is either temporarily disabling driver
# signature enforcement, or using Zadig (https://zadig.akeo.ie/) — a
# reputable, signed, widely used open-source tool that does the same
# WinUSB-by-interface-class binding through a properly signed driver.
_GENERIC_INF = r"""[Version]
Signature="$Windows NT$"
Class=USBDevice
ClassGuid={88bae032-5a81-49f0-bc3d-a4ff138216d6}
Provider=%ProviderName%
CatalogFile=android_fastboot_generic.cat
DriverVer=01/01/2026,1.0.0.0

[Manufacturer]
%ManufacturerName%=Standard,NTx86,NTamd64

[Standard.NTx86]
%DeviceName% = USB_Install, USB\Class_FF&SubClass_42&Prot_03

[Standard.NTamd64]
%DeviceName% = USB_Install, USB\Class_FF&SubClass_42&Prot_03

[USB_Install]
Include=winusb.inf
Needs=WINUSB.NT

[USB_Install.Services]
Include=winusb.inf
Needs=WINUSB.NT.Services

[USB_Install.HW]
AddReg=Dev_AddReg

[Dev_AddReg]
HKR,,DeviceInterfaceGUIDs,0x10000,"{f72fe0d4-cbcb-407d-8814-9ed673d0dd6b}"

[Strings]
ProviderName="LoveRoot"
ManufacturerName="Android"
DeviceName="Android Fastboot Interface (Generic WinUSB)"
"""


def generic_fastboot_driver_present() -> bool:
    return (GENERIC_DRIVER_DIR / "android_fastboot_generic.inf").is_file()


def ensure_generic_fastboot_driver(log=print) -> "Path":
    """
    Write out the generic class-matched fastboot driver (see _GENERIC_INF
    above) to disk. No download needed — we author this .inf ourselves,
    it's not fetched from anywhere.
    """
    if platform.system() != "Windows":
        raise BootstrapError("This driver is only applicable on Windows.")

    GENERIC_DRIVER_DIR.mkdir(parents=True, exist_ok=True)
    inf_path = GENERIC_DRIVER_DIR / "android_fastboot_generic.inf"
    inf_path.write_text(_GENERIC_INF, encoding="utf-8")
    log(f"Generic fastboot driver written to {inf_path}")
    return inf_path


def tools_present() -> bool:
    """True if adb + fastboot are already available (bundled or on PATH)."""
    for tool in ("adb", "fastboot"):
        local = TOOLS_DIR / _exe(tool)
        if local.is_file():
            continue
        if shutil.which(_exe(tool)):
            continue
        return False
    return True


def ensure_platform_tools(log=print, progress=None) -> None:
    """
    Make sure adb/fastboot are available, downloading Google's official
    platform-tools package into ./platform-tools if needed.

    `progress(fraction: float)` is an optional callback for a progress bar,
    called with values from 0.0 to 1.0.
    """
    if tools_present():
        log("platform-tools already present — skipping download.")
        return

    system = platform.system()
    url = _URLS.get(system)
    if not url:
        raise BootstrapError(f"No known platform-tools package for OS: {system}")

    log(f"adb/fastboot not found. Downloading official platform-tools for {system}...")
    TOOLS_DIR.parent.mkdir(parents=True, exist_ok=True)
    zip_path = BASE_DIR / "platform-tools.zip"

    def _reporthook(block_num, block_size, total_size):
        if progress and total_size > 0:
            progress(min(1.0, block_num * block_size / total_size))

    try:
        urllib.request.urlretrieve(url, zip_path, reporthook=_reporthook)
    except Exception as e:
        raise BootstrapError(
            f"Download failed ({e}). Check your internet connection, or manually "
            f"download platform-tools from {url} and unzip it into "
            f"'{TOOLS_DIR}'."
        ) from e

    log("Download complete. Extracting...")
    try:
        extract_dir = BASE_DIR / "_pt_extract_tmp"
        if extract_dir.exists():
            shutil.rmtree(extract_dir)
        with zipfile.ZipFile(zip_path, "r") as zf:
            zf.extractall(extract_dir)

        # The zip contains a top-level "platform-tools/" folder — merge its
        # contents into our TOOLS_DIR.
        extracted_tools = extract_dir / "platform-tools"
        TOOLS_DIR.mkdir(parents=True, exist_ok=True)
        for item in extracted_tools.iterdir():
            dest = TOOLS_DIR / item.name
            if dest.exists():
                if dest.is_dir():
                    shutil.rmtree(dest)
                else:
                    dest.unlink()
            shutil.move(str(item), str(dest))
    finally:
        zip_path.unlink(missing_ok=True)
        if extract_dir.exists():
            shutil.rmtree(extract_dir, ignore_errors=True)

    # On Linux/macOS the extracted binaries need the exec bit set.
    if system != "Windows":
        for tool in ("adb", "fastboot"):
            p = TOOLS_DIR / tool
            if p.is_file():
                p.chmod(p.stat().st_mode | 0o111)

    if not tools_present():
        raise BootstrapError(
            "platform-tools were downloaded but adb/fastboot still weren't found. "
            f"Check the contents of '{TOOLS_DIR}' manually."
        )

    log("platform-tools installed successfully.")
