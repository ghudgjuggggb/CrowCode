"""
bootstrap.py — auto-installs Android platform-tools (adb + fastboot) if missing.

Downloads the OFFICIAL Google package for the current OS from
https://developer.android.com/tools/releases/platform-tools
(dl.google.com is Google's own distribution server for these tools).

This only runs if ./platform-tools/adb(.exe) and fastboot(.exe) are not
already present next to the app, and are not already available on PATH.
"""

from __future__ import annotations

import os
import platform
import shutil
import urllib.request
import zipfile
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
TOOLS_DIR = BASE_DIR / "platform-tools"

_URLS = {
    "Windows": "https://dl.google.com/android/repo/platform-tools-latest-windows.zip",
    "Linux": "https://dl.google.com/android/repo/platform-tools-latest-linux.zip",
    "Darwin": "https://dl.google.com/android/repo/platform-tools-latest-darwin.zip",
}


class BootstrapError(RuntimeError):
    pass


def _exe(name: str) -> str:
    return name + (".exe" if platform.system() == "Windows" else "")


def tools_present() -> bool:
    """True if adb + fastboot are already available (bundled or on PATH)."""
    for tool in ("adb", "fastboot"):
        local = TOOLS_DIR / _exe(tool)
        if local.is_file():
            continue
        if shutil.which(_exe(tool)):
            continue
        return False
    return True


def ensure_platform_tools(log=print, progress=None) -> None:
    """
    Make sure adb/fastboot are available, downloading Google's official
    platform-tools package into ./platform-tools if needed.

    `progress(fraction: float)` is an optional callback for a progress bar,
    called with values from 0.0 to 1.0.
    """
    if tools_present():
        log("platform-tools already present — skipping download.")
        return

    system = platform.system()
    url = _URLS.get(system)
    if not url:
        raise BootstrapError(f"No known platform-tools package for OS: {system}")

    log(f"adb/fastboot not found. Downloading official platform-tools for {system}...")
    TOOLS_DIR.parent.mkdir(parents=True, exist_ok=True)
    zip_path = BASE_DIR / "platform-tools.zip"

    def _reporthook(block_num, block_size, total_size):
        if progress and total_size > 0:
            progress(min(1.0, block_num * block_size / total_size))

    try:
        urllib.request.urlretrieve(url, zip_path, reporthook=_reporthook)
    except Exception as e:
        raise BootstrapError(
            f"Download failed ({e}). Check your internet connection, or manually "
            f"download platform-tools from {url} and unzip it into "
            f"'{TOOLS_DIR}'."
        ) from e

    log("Download complete. Extracting...")
    try:
        extract_dir = BASE_DIR / "_pt_extract_tmp"
        if extract_dir.exists():
            shutil.rmtree(extract_dir)
        with zipfile.ZipFile(zip_path, "r") as zf:
            zf.extractall(extract_dir)

        # The zip contains a top-level "platform-tools/" folder — merge its
        # contents into our TOOLS_DIR.
        extracted_tools = extract_dir / "platform-tools"
        TOOLS_DIR.mkdir(parents=True, exist_ok=True)
        for item in extracted_tools.iterdir():
            dest = TOOLS_DIR / item.name
            if dest.exists():
                if dest.is_dir():
                    shutil.rmtree(dest)
                else:
                    dest.unlink()
            shutil.move(str(item), str(dest))
    finally:
        zip_path.unlink(missing_ok=True)
        if extract_dir.exists():
            shutil.rmtree(extract_dir, ignore_errors=True)

    # On Linux/macOS the extracted binaries need the exec bit set.
    if system != "Windows":
        for tool in ("adb", "fastboot"):
            p = TOOLS_DIR / tool
            if p.is_file():
                p.chmod(p.stat().st_mode | 0o111)

    if not tools_present():
        raise BootstrapError(
            "platform-tools were downloaded but adb/fastboot still weren't found. "
            f"Check the contents of '{TOOLS_DIR}' manually."
        )

    log("platform-tools installed successfully.")
