"""
LoveRoot — GUI front-end.

Workflow shown to the user:
  1. Detect device
  2. (Windows) Optionally install a driver .inf the user points to
  3. User selects their own pre-patched boot.img
  4. Confirm -> reboot to bootloader -> flash -> reboot -> verify root

Every destructive step (driver install, flashing) requires an explicit
button press and, for flashing, a typed confirmation — this tool does not
auto-flash the instant a device is detected.
"""

import os
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext, ttk

from device_manager import DeviceManager, LoveRootError, DeviceInfo
from bootstrap import ensure_platform_tools, BootstrapError, tools_present

BOOT_IMG_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "patched_boot_image_HERE")


class LoveRootApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("LoveRoot")
        self.geometry("620x480")
        self.resizable(False, False)

        self.device: DeviceInfo | None = None
        self.boot_img_path: str | None = None
        self.manager: DeviceManager | None = None

        self._build_ui()
        self._start_bootstrap()

    def _start_bootstrap(self):
        def progress(fraction: float):
            self.after(0, lambda: self.tools_progress.configure(value=fraction * 100))

        def task():
            try:
                if tools_present():
                    self._log("adb/fastboot found.")
                else:
                    ensure_platform_tools(log=self._log, progress=progress)
                self.manager = DeviceManager(log=self._log)
                self.after(0, self._on_tools_ready)
            except BootstrapError as e:
                self._log(f"ERROR: {e}")
                self.after(0, lambda: self.tools_label.configure(
                    text="Failed to get adb/fastboot — see log", fg="#c0392b"))
                self.after(0, lambda: messagebox.showerror("Setup failed", str(e)))

        threading.Thread(target=task, daemon=True).start()

    def _on_tools_ready(self):
        self.tools_label.configure(text="adb/fastboot ready", fg="green")
        self.tools_progress.configure(value=100)
        self.detect_btn.configure(state="normal")

    # ---------- UI ----------

    def _build_ui(self):
        pad = {"padx": 10, "pady": 6}

        header = tk.Label(self, text="LoveRoot", font=("Segoe UI", 18, "bold"))
        header.pack(**pad)

        subtitle = tk.Label(
            self,
            text="Flash a boot image YOU prepared for YOUR device. This tool\n"
                 "does not patch images or unlock bootloaders for you.",
            fg="#555",
        )
        subtitle.pack()

        step0 = tk.Frame(self)
        step0.pack(fill="x", **pad)
        self.tools_label = tk.Label(step0, text="Checking for adb/fastboot...", fg="#888")
        self.tools_label.pack(side="left")
        self.tools_progress = ttk.Progressbar(step0, length=200, mode="determinate")
        self.tools_progress.pack(side="left", padx=10)

        step1 = tk.Frame(self)
        step1.pack(fill="x", **pad)
        self.detect_btn = tk.Button(step1, text="1. Detect device", command=self.on_detect, width=20, state="disabled")
        self.detect_btn.pack(side="left")
        self.device_label = tk.Label(step1, text="No device detected", fg="#888")
        self.device_label.pack(side="left", padx=10)

        step2 = tk.Frame(self)
        step2.pack(fill="x", **pad)
        tk.Button(step2, text="2. Select patched boot.img", command=self.on_select_img, width=20).pack(side="left")
        self.img_label = tk.Label(step2, text="No file selected", fg="#888")
        self.img_label.pack(side="left", padx=10)

        step3 = tk.Frame(self)
        step3.pack(fill="x", **pad)
        self.flash_btn = tk.Button(
            step3, text="3. Flash + Root (confirm required)", command=self.on_flash,
            width=30, bg="#c0392b", fg="white", state="disabled"
        )
        self.flash_btn.pack(side="left")

        tk.Label(self, text="Log:").pack(anchor="w", padx=10)
        self.log_box = scrolledtext.ScrolledText(self, height=16, state="disabled", font=("Consolas", 9))
        self.log_box.pack(fill="both", expand=True, padx=10, pady=(0, 10))

    def _log(self, msg: str):
        def _append():
            self.log_box.configure(state="normal")
            self.log_box.insert("end", msg + "\n")
            self.log_box.see("end")
            self.log_box.configure(state="disabled")
        self.after(0, _append)

    def _update_flash_button(self):
        if self.device and self.boot_img_path:
            self.flash_btn.configure(state="normal")

    # ---------- Actions ----------

    def on_detect(self):
        def task():
            try:
                self.device = self.manager.detect_device()
                text = f"{self.device.mode.upper()} — {self.device.serial}"
                if self.device.model:
                    text += f" ({self.device.model})"
                self.device_label.configure(text=text, fg="green")
                self._update_flash_button()
            except LoveRootError as e:
                self._log(f"ERROR: {e}")
                messagebox.showerror("Detection failed", str(e))
        threading.Thread(target=task, daemon=True).start()

    def on_select_img(self):
        os.makedirs(BOOT_IMG_DIR, exist_ok=True)
        path = filedialog.askopenfilename(
            title="Select your pre-patched boot.img",
            initialdir=BOOT_IMG_DIR,
            filetypes=[("Boot image", "*.img"), ("All files", "*.*")],
        )
        if path:
            self.boot_img_path = path
            self.img_label.configure(text=path, fg="green")
            self._update_flash_button()

    def on_flash(self):
        if not self.device or not self.boot_img_path:
            return

        warning = (
            "This will overwrite the 'boot' partition on your device with:\n\n"
            f"{self.boot_img_path}\n\n"
            "This is only safe if that image was built specifically for your "
            "exact device model and firmware version. A mismatched image can "
            "make the device unbootable, and this cannot always be undone.\n\n"
            "Type CONFIRM below to proceed."
        )
        import tkinter.simpledialog as sd
        answer = sd.askstring("Confirm flash", warning)
        if answer != "CONFIRM":
            self._log("Flash cancelled (confirmation not given).")
            return

        self.flash_btn.configure(state="disabled")

        def task():
            try:
                self.manager.reboot_to_bootloader(self.device)
                self.manager.flash_boot_image(self.boot_img_path)
                self.manager.reboot_device()
                rooted = self.manager.verify_root(self.device.serial)
                if rooted:
                    messagebox.showinfo("Done", "Root access verified.")
                else:
                    messagebox.showwarning(
                        "Flashed, root not confirmed",
                        "The image flashed, but 'su' wasn't detected. Check your "
                        "root manager app on the device."
                    )
            except LoveRootError as e:
                self._log(f"ERROR: {e}")
                messagebox.showerror("Flash failed", str(e))
            finally:
                self.flash_btn.configure(state="normal")

        threading.Thread(target=task, daemon=True).start()


if __name__ == "__main__":
    app = LoveRootApp()
    app.mainloop()
