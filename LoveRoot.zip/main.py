"""
LoveRoot — GUI front-end.

Workflow shown to the user:
  1. Detect device
  2. (Windows) Optionally install a driver .inf the user points to
  3. User selects their own pre-patched boot.img
  4. Confirm -> reboot to bootloader -> flash -> reboot -> verify root

Every destructive step (driver install, flashing) requires an explicit
button press and, for flashing, a typed confirmation — this tool does not
auto-flash the instant a device is detected.
"""

import os
import platform
import threading
import webbrowser
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext, ttk

from device_manager import DeviceManager, LoveRootError, DeviceInfo
from bootstrap import (
    ensure_platform_tools, ensure_usb_driver, ensure_generic_fastboot_driver,
    BootstrapError, tools_present,
)
from firmware_tools import extract_boot_images, FirmwareToolsError

BOOT_IMG_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "patched_boot_image_HERE")


class LoveRootApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("LoveRoot")
        self.geometry("640x760")
        self.resizable(False, False)

        self.device: DeviceInfo | None = None
        self.boot_img_path: str | None = None
        self.manager: DeviceManager | None = None

        self._build_ui()
        self._start_bootstrap()

    def _start_bootstrap(self):
        def progress(fraction: float):
            self.after(0, lambda: self.tools_progress.configure(value=fraction * 100))

        def task():
            try:
                if tools_present():
                    self._log("adb/fastboot found.")
                else:
                    ensure_platform_tools(log=self._log, progress=progress)
                self.manager = DeviceManager(log=self._log)
                self.after(0, self._on_tools_ready)
            except BootstrapError as e:
                self._log(f"ERROR: {e}")
                self.after(0, lambda: self.tools_label.configure(
                    text="Failed to get adb/fastboot — see log", fg="#c0392b"))
                self.after(0, lambda: messagebox.showerror("Setup failed", str(e)))

        threading.Thread(target=task, daemon=True).start()

    def _on_tools_ready(self):
        self.tools_label.configure(text="adb/fastboot ready", fg="green")
        self.tools_progress.configure(value=100)
        self.detect_btn.configure(state="normal")

    # ---------- UI ----------

    def _build_ui(self):
        pad = {"padx": 10, "pady": 6}

        header = tk.Label(self, text="LoveRoot", font=("Segoe UI", 18, "bold"))
        header.pack(**pad)

        subtitle = tk.Label(
            self,
            text="Flash a boot image YOU prepared for YOUR device. This tool\n"
                 "does not patch images or unlock bootloaders for you.",
            fg="#555",
        )
        subtitle.pack()

        step0 = tk.Frame(self)
        step0.pack(fill="x", **pad)
        self.tools_label = tk.Label(step0, text="Checking for adb/fastboot...", fg="#888")
        self.tools_label.pack(side="left")
        self.tools_progress = ttk.Progressbar(step0, length=200, mode="determinate")
        self.tools_progress.pack(side="left", padx=10)

        step1 = tk.Frame(self)
        step1.pack(fill="x", **pad)
        self.detect_btn = tk.Button(step1, text="1. Detect device", command=self.on_detect, width=20, state="disabled")
        self.detect_btn.pack(side="left")
        self.device_label = tk.Label(step1, text="No device detected", fg="#888")
        self.device_label.pack(side="left", padx=10)

        unlock_title = tk.Label(self, text="Bootloader unlock helper:", fg="#333", font=("Segoe UI", 9, "bold"))
        unlock_title.pack(anchor="w", padx=10, pady=(6, 0))
        unlock_note = tk.Label(
            self,
            text="Xiaomi requires their own Mi Unlock Tool + account — this can't be automated locally",
            fg="#888", font=("Segoe UI", 8),
        )
        unlock_note.pack(anchor="w", padx=10)

        step_unlock1 = tk.Frame(self)
        step_unlock1.pack(fill="x", **pad)
        self.check_unlock_btn = tk.Button(step_unlock1, text="Check unlock status", command=self.on_check_unlock_status, width=20)
        self.check_unlock_btn.pack(side="left")
        self.unlock_status_label = tk.Label(step_unlock1, text="Not checked yet", fg="#888")
        self.unlock_status_label.pack(side="left", padx=10)

        step_unlock2 = tk.Frame(self)
        step_unlock2.pack(fill="x", **pad)
        self.try_unlock_btn = tk.Button(step_unlock2, text="Try fastboot unlock", command=self.on_try_fastboot_unlock, width=20)
        self.try_unlock_btn.pack(side="left")
        tk.Label(step_unlock2, text="Harmless to try; will likely be refused on Xiaomi", fg="#888").pack(side="left", padx=10)

        step_unlock3 = tk.Frame(self)
        step_unlock3.pack(fill="x", **pad)
        tk.Button(step_unlock3, text="Open official Mi Unlock page", command=self.on_open_mi_unlock, width=20).pack(side="left")
        tk.Label(step_unlock3, text="en.miui.com — requires Mi account + waiting period", fg="#888").pack(side="left", padx=10)

        step_fb = tk.Frame(self)
        step_fb.pack(fill="x", **pad)
        self.fastboot_btn = tk.Button(
            step_fb, text="2. Switch to fastboot", command=self.on_switch_fastboot,
            width=20, state="disabled"
        )
        self.fastboot_btn.pack(side="left")
        self.fastboot_label = tk.Label(step_fb, text="Device not in fastboot yet", fg="#888")
        self.fastboot_label.pack(side="left", padx=10)

        step_drv = tk.Frame(self)
        step_drv.pack(fill="x", **pad)
        self.driver_btn = tk.Button(
            step_drv, text="Fix: install USB driver", command=self.on_install_driver, width=20
        )
        self.driver_btn.pack(side="left")
        self.driver_label = tk.Label(
            step_drv,
            text="If fastboot doesn't detect the phone, click this",
            fg="#888",
        )
        self.driver_label.pack(side="left", padx=10)
        if platform.system() != "Windows":
            self.driver_btn.configure(state="disabled")
            self.driver_label.configure(text="Windows only")

        step_drv2 = tk.Frame(self)
        step_drv2.pack(fill="x", **pad)
        self.driver2_btn = tk.Button(
            step_drv2, text="Fix: generic fastboot driver", command=self.on_install_generic_driver, width=20
        )
        self.driver2_btn.pack(side="left")
        self.driver2_label = tk.Label(
            step_drv2,
            text="Still not detected? Try this (works for non-Pixel phones too)",
            fg="#888",
        )
        self.driver2_label.pack(side="left", padx=10)
        if platform.system() != "Windows":
            self.driver2_btn.configure(state="disabled")
            self.driver2_label.configure(text="Windows only")

        get_img_label = tk.Label(self, text="Get a boot image (pick one):", fg="#333", font=("Segoe UI", 9, "bold"))
        get_img_label.pack(anchor="w", padx=10, pady=(6, 0))

        step_extract = tk.Frame(self)
        step_extract.pack(fill="x", **pad)
        tk.Button(step_extract, text="Extract from firmware archive", command=self.on_extract_firmware, width=25).pack(side="left")
        self.extract_label = tk.Label(step_extract, text="Pulls boot.img/init_boot.img out of a stock ROM zip/tgz", fg="#888")
        self.extract_label.pack(side="left", padx=10)

        step_pull = tk.Frame(self)
        step_pull.pack(fill="x", **pad)
        self.pull_btn = tk.Button(step_pull, text="Pull patched file from phone", command=self.on_pull_from_phone, width=25, state="disabled")
        self.pull_btn.pack(side="left")
        self.pull_label = tk.Label(step_pull, text="After patching in KernelSU/Magisk app on-device", fg="#888")
        self.pull_label.pack(side="left", padx=10)

        step_fetch = tk.Frame(self)
        step_fetch.pack(fill="x", **pad)
        self.fetch_btn = tk.Button(step_fetch, text="Try: fetch from device (experimental)", command=self.on_fetch_experimental, width=25, state="disabled")
        self.fetch_btn.pack(side="left")
        self.fetch_label = tk.Label(step_fetch, text="No root needed, but unsupported on many non-Pixel devices", fg="#888")
        self.fetch_label.pack(side="left", padx=10)

        step2 = tk.Frame(self)
        step2.pack(fill="x", **pad)
        tk.Button(step2, text="3. Select patched boot.img", command=self.on_select_img, width=20).pack(side="left")
        self.img_label = tk.Label(step2, text="No file selected", fg="#888")
        self.img_label.pack(side="left", padx=10)

        step_part = tk.Frame(self)
        step_part.pack(fill="x", **pad)
        tk.Label(step_part, text="Target partition:", width=20, anchor="w").pack(side="left")
        self.partition_var = tk.StringVar(value="boot")
        partition_menu = ttk.Combobox(
            step_part, textvariable=self.partition_var,
            values=["boot", "init_boot", "init_boot_a", "init_boot_b"],
            state="readonly", width=15,
        )
        partition_menu.pack(side="left")
        tk.Label(
            step_part,
            text="Check in KernelSU/Magisk which one it patched — wrong choice can brick",
            fg="#c0392b",
        ).pack(side="left", padx=10)

        step3 = tk.Frame(self)
        step3.pack(fill="x", **pad)
        self.flash_btn = tk.Button(
            step3, text="4. Flash + Root (confirm required)", command=self.on_flash,
            width=30, bg="#c0392b", fg="white", state="disabled"
        )
        self.flash_btn.pack(side="left")

        tk.Label(self, text="Log:").pack(anchor="w", padx=10)
        self.log_box = scrolledtext.ScrolledText(self, height=16, state="disabled", font=("Consolas", 9))
        self.log_box.pack(fill="both", expand=True, padx=10, pady=(0, 10))

    def _log(self, msg: str):
        def _append():
            self.log_box.configure(state="normal")
            self.log_box.insert("end", msg + "\n")
            self.log_box.see("end")
            self.log_box.configure(state="disabled")
        self.after(0, _append)

    def _update_flash_button(self):
        if self.device and self.boot_img_path:
            self.flash_btn.configure(state="normal")

    # ---------- Actions ----------

    def on_detect(self):
        def task():
            try:
                self.device = self.manager.detect_device()
                text = f"{self.device.mode.upper()} — {self.device.serial}"
                if self.device.model:
                    text += f" ({self.device.model})"
                self.device_label.configure(text=text, fg="green")
                self.fetch_btn.configure(state="normal")
                if self.device.mode == "adb":
                    self.pull_btn.configure(state="normal")
                if self.device.mode == "fastboot":
                    self.fastboot_label.configure(text="Already in fastboot", fg="green")
                    self._update_flash_button()
                else:
                    self.fastboot_btn.configure(state="normal")
                    self._log("Device found in ADB mode. Click 'Switch to fastboot' "
                               "or it will switch automatically when you flash.")
                    # Switch automatically so the user doesn't have to do it by hand.
                    self.on_switch_fastboot()
            except LoveRootError as e:
                self._log(f"ERROR: {e}")
                messagebox.showerror("Detection failed", str(e))
        threading.Thread(target=task, daemon=True).start()

    def on_install_driver(self):
        self.driver_btn.configure(state="disabled")
        self.driver_label.configure(text="Downloading driver...", fg="#e67e22")

        def task():
            try:
                inf_path = ensure_usb_driver(log=self._log)
                self.driver_label.configure(text="Installing driver (approve the UAC prompt)...", fg="#e67e22")
                self.manager.install_driver(str(inf_path))
                self.driver_label.configure(text="Driver installed — try 'Switch to fastboot' again", fg="green")
            except BootstrapError as e:
                self._log(f"ERROR: {e}")
                self.driver_label.configure(text="Driver download failed — see log", fg="#c0392b")
                messagebox.showerror("Driver download failed", str(e))
            except LoveRootError as e:
                self._log(f"ERROR: {e}")
                self.driver_label.configure(text="Driver install failed — see log", fg="#c0392b")
                messagebox.showerror("Driver install failed", str(e))
            finally:
                self.driver_btn.configure(state="normal")

        threading.Thread(target=task, daemon=True).start()

    def on_install_generic_driver(self):
        self.driver2_btn.configure(state="disabled")
        self.driver2_label.configure(text="Installing generic driver...", fg="#e67e22")

        def task():
            try:
                inf_path = ensure_generic_fastboot_driver(log=self._log)
                self.driver2_label.configure(text="Installing driver (approve the UAC prompt)...", fg="#e67e22")
                self.manager.install_driver(str(inf_path))
                self.driver2_label.configure(text="Driver installed — try 'Switch to fastboot' again", fg="green")
            except (BootstrapError, LoveRootError) as e:
                self._log(f"ERROR: {e}")
                self.driver2_label.configure(text="Failed — see log", fg="#c0392b")
                messagebox.showerror("Driver install failed", str(e))
            finally:
                self.driver2_btn.configure(state="normal")

        threading.Thread(target=task, daemon=True).start()

    def on_switch_fastboot(self):
        if not self.device:
            return
        self.fastboot_btn.configure(state="disabled")

        def task():
            try:
                if self.device.mode == "adb":
                    self.fastboot_label.configure(text="Switching to fastboot...", fg="#e67e22")
                serial = self.manager.reboot_to_bootloader(self.device)
                self.device = DeviceInfo(serial=serial or self.device.serial, mode="fastboot")
                self.fastboot_label.configure(text=f"In fastboot — {self.device.serial}", fg="green")
                self._update_flash_button()
            except LoveRootError as e:
                self._log(f"ERROR: {e}")
                self.fastboot_label.configure(text="Failed to switch to fastboot", fg="#c0392b")
                if platform.system() == "Windows":
                    self._log("Tip: Windows often can't see a phone in fastboot mode without "
                               "the right driver. Try 'Fix: install USB driver' first, and if "
                               "that doesn't help (common for non-Pixel phones), try "
                               "'Fix: generic fastboot driver'.")
                messagebox.showerror("Fastboot switch failed", str(e))
                self.fastboot_btn.configure(state="normal")

        threading.Thread(target=task, daemon=True).start()

    def on_check_unlock_status(self):
        if not self.device:
            messagebox.showwarning("No device", "Detect the phone first.")
            return
        self.unlock_status_label.configure(text="Checking...", fg="#e67e22")

        def task():
            try:
                if self.device.mode == "fastboot":
                    state = self.manager.check_bootloader_state(self.device)
                    text = {"yes": "UNLOCKED", "no": "LOCKED", "unknown": "Unknown (device didn't report it)"}[state]
                    color = "green" if state == "yes" else ("#c0392b" if state == "no" else "#888")
                    self.unlock_status_label.configure(text=text, fg=color)
                else:
                    toggle = self.manager.check_oem_unlock_toggle(self.device.serial)
                    if toggle is None:
                        self.unlock_status_label.configure(text="Switch to fastboot to check unlock state", fg="#888")
                    else:
                        note = "OEM unlocking toggle: ON" if toggle else "OEM unlocking toggle: OFF (enable it first)"
                        self.unlock_status_label.configure(text=note, fg="green" if toggle else "#c0392b")
            except LoveRootError as e:
                self._log(f"ERROR: {e}")
                self.unlock_status_label.configure(text="Check failed — see log", fg="#c0392b")

        threading.Thread(target=task, daemon=True).start()

    def on_try_fastboot_unlock(self):
        if not self.device or self.device.mode != "fastboot":
            messagebox.showwarning("Not in fastboot", "Switch the device to fastboot mode first.")
            return
        confirm = messagebox.askyesno(
            "Attempt unlock",
            "This will run 'fastboot flashing unlock'. On Xiaomi devices this is "
            "almost always refused (they require the official Mi Unlock Tool "
            "instead) — but it's harmless to try. IMPORTANT: if it DOES succeed "
            "on any device, bootloader unlock typically wipes all user data. "
            "Continue?"
        )
        if not confirm:
            return

        def task():
            try:
                output = self.manager.try_fastboot_unlock(self.device)
                self._log(f"Unlock command output: {output}")
                messagebox.showinfo("Unlock command sent", "Follow any on-screen prompts on the phone itself.")
            except LoveRootError as e:
                self._log(f"ERROR: {e}")
                messagebox.showinfo("Refused (expected on Xiaomi)", str(e))

        threading.Thread(target=task, daemon=True).start()

    def on_open_mi_unlock(self):
        webbrowser.open(DeviceManager.OFFICIAL_MI_UNLOCK_URL)
        self._log(f"Opened {DeviceManager.OFFICIAL_MI_UNLOCK_URL} in your browser.")

    def on_extract_firmware(self):
        archive = filedialog.askopenfilename(
            title="Select stock firmware archive (.tgz/.tar.gz/.zip)",
            filetypes=[("Firmware archive", "*.tgz *.tar.gz *.zip"), ("All files", "*.*")],
        )
        if not archive:
            return
        self.extract_label.configure(text="Extracting (this can take a while for multi-GB files)...", fg="#e67e22")

        def task():
            try:
                os.makedirs(BOOT_IMG_DIR, exist_ok=True)
                found = extract_boot_images(archive, BOOT_IMG_DIR, log=self._log)
                self.extract_label.configure(
                    text=f"Extracted: {', '.join(os.path.basename(f) for f in found)} "
                         f"— now patch it in KernelSU/Magisk on your phone",
                    fg="green",
                )
            except FirmwareToolsError as e:
                self._log(f"ERROR: {e}")
                self.extract_label.configure(text="Extraction failed — see log", fg="#c0392b")
                messagebox.showerror("Extraction failed", str(e))

        threading.Thread(target=task, daemon=True).start()

    def on_pull_from_phone(self):
        if not self.device or self.device.mode != "adb":
            messagebox.showwarning("Not available", "Detect the phone in ADB mode first.")
            return
        self.pull_label.configure(text="Listing /sdcard/Download/ ...", fg="#e67e22")

        def list_task():
            try:
                files = self.manager.list_phone_downloads(self.device.serial)
                candidates = [f for f in files if f.lower().endswith(".img")]
                if not candidates:
                    self.pull_label.configure(text="No .img files found in Download folder", fg="#c0392b")
                    messagebox.showinfo(
                        "Nothing found",
                        "No .img files in /sdcard/Download/ on the phone. "
                        "Patch a boot image in KernelSU/Magisk first, then try again."
                    )
                    return
                self.after(0, lambda: self._prompt_pick_and_pull(candidates))
            except LoveRootError as e:
                self._log(f"ERROR: {e}")
                self.pull_label.configure(text="Failed to list files — see log", fg="#c0392b")
                messagebox.showerror("Pull failed", str(e))

        threading.Thread(target=list_task, daemon=True).start()

    def _prompt_pick_and_pull(self, candidates: list[str]):
        import tkinter.simpledialog as sd
        prompt = "Files found in /sdcard/Download/:\n\n" + "\n".join(candidates) + "\n\nType the exact filename to pull:"
        choice = sd.askstring("Pick a file", prompt)
        if not choice or choice not in candidates:
            self._log("Pull cancelled or invalid filename.")
            return
        self.pull_label.configure(text=f"Pulling {choice}...", fg="#e67e22")

        def pull_task():
            try:
                os.makedirs(BOOT_IMG_DIR, exist_ok=True)
                local_dest = os.path.join(BOOT_IMG_DIR, choice)
                self.manager.pull_from_phone(self.device.serial, f"/sdcard/Download/{choice}", local_dest)
                self.pull_label.configure(text=f"Pulled to {local_dest}", fg="green")
            except LoveRootError as e:
                self._log(f"ERROR: {e}")
                self.pull_label.configure(text="Pull failed — see log", fg="#c0392b")
                messagebox.showerror("Pull failed", str(e))

        threading.Thread(target=pull_task, daemon=True).start()

    def on_fetch_experimental(self):
        if not self.device:
            return
        partition = self.partition_var.get() if hasattr(self, "partition_var") else "boot"
        confirm = messagebox.askyesno(
            "Experimental feature",
            f"This will try to read the '{partition}' partition directly off the "
            f"device via 'fastboot fetch', without needing existing root.\n\n"
            f"This is unreliable on many non-Pixel devices (including most Unisoc "
            f"phones) and may simply fail with no harm done. Continue?"
        )
        if not confirm:
            return
        self.fetch_label.configure(text="Attempting fetch...", fg="#e67e22")

        def task():
            try:
                os.makedirs(BOOT_IMG_DIR, exist_ok=True)
                dest = os.path.join(BOOT_IMG_DIR, f"{partition}_from_device.img")
                self.manager.fetch_partition_experimental(self.device, partition, dest)
                self.fetch_label.configure(text=f"Fetched to {dest}", fg="green")
            except LoveRootError as e:
                self._log(f"ERROR: {e}")
                self.fetch_label.configure(text="Not supported on this device — see log", fg="#c0392b")
                messagebox.showerror("Fetch failed", str(e))

        threading.Thread(target=task, daemon=True).start()

    def on_select_img(self):
        os.makedirs(BOOT_IMG_DIR, exist_ok=True)
        path = filedialog.askopenfilename(
            title="Select your pre-patched boot.img",
            initialdir=BOOT_IMG_DIR,
            filetypes=[("Boot image", "*.img"), ("All files", "*.*")],
        )
        if path:
            self.boot_img_path = path
            self.img_label.configure(text=path, fg="green")
            self._update_flash_button()

    def on_flash(self):
        if not self.device or not self.boot_img_path:
            return
        partition = self.partition_var.get()

        warning = (
            f"This will overwrite the '{partition}' partition on your device with:\n\n"
            f"{self.boot_img_path}\n\n"
            "This is only safe if that image was built specifically for your "
            "exact device model and firmware version, AND if you've picked the "
            "correct target partition (check what KernelSU/Magisk patched — "
            "many modern devices use init_boot, not boot). A mismatched image "
            "or wrong partition can make the device unbootable, and this cannot "
            "always be undone.\n\n"
            "Type CONFIRM below to proceed."
        )
        import tkinter.simpledialog as sd
        answer = sd.askstring("Confirm flash", warning)
        if answer != "CONFIRM":
            self._log("Flash cancelled (confirmation not given).")
            return

        self.flash_btn.configure(state="disabled")

        def task():
            try:
                self.manager.reboot_to_bootloader(self.device)
                self.manager.flash_boot_image(self.boot_img_path, partition=partition)
                self.manager.reboot_device()
                rooted = self.manager.verify_root(self.device.serial)
                if rooted:
                    messagebox.showinfo("Done", "Root access verified.")
                else:
                    messagebox.showwarning(
                        "Flashed, root not confirmed",
                        "The image flashed, but 'su' wasn't detected. Check your "
                        "root manager app on the device."
                    )
            except LoveRootError as e:
                self._log(f"ERROR: {e}")
                messagebox.showerror("Flash failed", str(e))
            finally:
                self.flash_btn.configure(state="normal")

        threading.Thread(target=task, daemon=True).start()


if __name__ == "__main__":
    app = LoveRootApp()
    app.mainloop()
