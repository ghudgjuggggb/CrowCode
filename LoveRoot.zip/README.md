# LoveRoot

A GUI tool that flashes a **pre-patched boot image you supply** to the `boot`
partition of a connected Android device via fastboot, then verifies root.

## What this tool does NOT do

- **Does not create or patch boot images.** You need to prepare `boot.img`
  yourself for your exact device + firmware version (e.g. by extracting your
  stock boot image and patching it with Magisk on the device itself). Flashing
  an image built for the wrong model/firmware can hard-brick the device.
- **Does not unlock the bootloader.** You must run `fastboot flashing unlock`
  (or your OEM's equivalent) yourself, after reading your OEM's specific
  warnings — this action typically wipes all user data.
- **Does not silently install drivers.** On Windows, driver install goes
  through `pnputil` with a UAC prompt you have to approve.

## Requirements

- Python 3.10+ (only needed if running from source — the built .exe is standalone)
- An internet connection the *first* time you run it, if `adb`/`fastboot`
  aren't already installed (see below)
- A phone with:
  - USB debugging enabled (Settings → Developer Options)
  - Bootloader already unlocked
  - A patched `boot.img` prepared in advance for that exact model/build

## Where to put your patched boot image

Put your pre-patched `boot.img` into:

```
LoveRoot/patched_boot_image_HERE/
```

The "Select patched boot.img" button opens directly in this folder. You can
still browse elsewhere if your file lives somewhere else.

## Automatic adb/fastboot install

On first launch, LoveRoot checks whether `adb`/`fastboot` are already
available (bundled in `./platform-tools/` or on your system `PATH`). If not,
it downloads Google's own official platform-tools package for your OS
straight from `dl.google.com` and unpacks it into `./platform-tools/` —
no manual setup needed. The "Detect device" button stays disabled until this
finishes. If the download fails (e.g. no internet, or the network is
restricted), the log will show the direct download URL so you can grab it
and unzip it into `./platform-tools/` yourself.

## Project layout

```
LoveRoot/
├── main.py                       # Tkinter GUI
├── device_manager.py             # adb/fastboot orchestration
├── bootstrap.py                  # auto-downloads adb/fastboot if missing
├── patched_boot_image_HERE/      # <- put your patched boot.img here
├── platform-tools/               # auto-populated on first run (or bring your own)
└── assets/
```

## Running from source

```bash
pip install --upgrade pip   # no extra deps needed, Tkinter is stdlib
python main.py
```

## Building LoveRoot.exe

```bash
pip install pyinstaller
pyinstaller --noconsole --onefile --name LoveRoot main.py
```

The .exe will be in `dist/LoveRoot.exe`. Ship it alongside a `platform-tools/`
folder (containing `adb.exe`/`fastboot.exe`) in the same directory, or require
users to have platform-tools on their PATH.

## Usage flow

1. **Detect device** — finds the phone in ADB or fastboot mode, shows model.
2. **Select patched boot.img** — you pick the file; the tool never guesses.
3. **Flash + Root** — shows a warning describing exactly what will be
   overwritten and requires you to type `CONFIRM` before anything happens.
   Then it reboots to bootloader, runs `fastboot flash boot <file>`, reboots,
   and polls for root via `su -c id`.

## Safety notes

- Always keep a full stock firmware package for your device on hand so you
  can recover via `fastboot flash boot stock_boot.img` if something goes wrong.
- This flashes the `boot` partition only — it doesn't touch `system`,
  `vendor`, `userdata`, or partition tables.
- If `fastboot flash` fails partway, do not disconnect the device; consult
  your device's specific unbrick/EDL recovery procedure.
