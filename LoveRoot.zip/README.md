# LoveRoot

A GUI tool that flashes a **pre-patched boot image you supply** to the `boot`
partition of a connected Android device via fastboot, then verifies root.

## What this tool does NOT do

- **Does not create or patch boot images.** You need to prepare `boot.img`
  yourself for your exact device + firmware version (e.g. by extracting your
  stock boot image and patching it with Magisk on the device itself). Flashing
  an image built for the wrong model/firmware can hard-brick the device.
- **Does not unlock the bootloader.** You must run `fastboot flashing unlock`
  (or your OEM's equivalent) yourself, after reading your OEM's specific
  warnings — this action typically wipes all user data.
- **Does not silently install drivers.** On Windows, driver install goes
  through `pnputil` with a UAC prompt you have to approve.

## Requirements

- Python 3.10+ (only needed if running from source — the built .exe is standalone)
- An internet connection the *first* time you run it, if `adb`/`fastboot`
  aren't already installed (see below)
- A phone with:
  - USB debugging enabled (Settings → Developer Options)
  - Bootloader already unlocked
  - A patched `boot.img` prepared in advance for that exact model/build

## Bootloader unlock helper

LoveRoot can't unlock the bootloader itself — for Xiaomi devices, unlock
requires their own signed **Mi Unlock Tool**, a logged-in Mi account, and
usually a mandatory waiting period enforced server-side. There's no local
command that replaces that server-side approval. What LoveRoot does offer:

- **"Check unlock status"** — reads the actual `unlocked: yes/no` state from
  fastboot (or the OEM-unlock toggle from ADB if not yet in fastboot mode).
- **"Try fastboot unlock"** — attempts the generic `fastboot flashing unlock`
  command. On Xiaomi this is refused (they disable this path deliberately),
  but it's harmless to try, and it *is* enough on some other OEMs.
- **"Open official Mi Unlock page"** — opens `en.miui.com/unlock` in your
  browser, which is the actual, only supported way to unlock a Xiaomi
  bootloader.

LoveRoot does NOT patch boot images itself (see below for why) — but it
offers three ways to get one into place with less manual work:

1. **"Extract from firmware archive"** — point it at a stock ROM `.tgz`/
   `.zip` you've downloaded, and it pulls out `boot.img`/`init_boot.img`
   without unpacking the whole multi-GB archive. Still a STOCK image — you
   then patch it in the KernelSU/Magisk app on your phone.
2. **"Pull patched file from phone"** — once you've patched a boot image
   with the KernelSU/Magisk app on-device (usually saved to
   `/sdcard/Download/`), this lists `.img` files there and `adb pull`s the
   one you pick straight into `patched_boot_image_HERE/`.
3. **"Try: fetch from device (experimental)"** — attempts `fastboot fetch`
   to read a partition directly off the phone without needing existing
   root. This is a genuinely unreliable feature outside Pixel-class
   devices (many vendors, including Unisoc-based phones, don't support
   it) — it's included because it costs nothing to try and does no harm
   if it fails, not because it's guaranteed to work.

### Why LoveRoot doesn't patch boot images itself

Injecting Magisk/KernelSU into a boot image means unpacking and
repacking the kernel/ramdisk in their specific internal format — logic
that Magisk and KernelSU implement in their own extensively tested
`magiskboot` tooling. Reimplementing that from scratch here would trade a
proven tool for an untested one, on a step where getting it wrong can
brick the device. Patch on-device with the official app instead — it's
both safer and the image is then guaranteed to match your running system.

## Automatic adb/fastboot install

On first launch, LoveRoot checks whether `adb`/`fastboot` are already
available (bundled in `./platform-tools/` or on your system `PATH`). If not,
it downloads Google's own official platform-tools package for your OS
straight from `dl.google.com` and unpacks it into `./platform-tools/` —
no manual setup needed. The "Detect device" button stays disabled until this
finishes. If the download fails (e.g. no internet, or the network is
restricted), the log will show the direct download URL so you can grab it
and unzip it into `./platform-tools/` yourself.

## Automatic USB driver install (Windows, fixes "not detected in fastboot")

Windows uses a different USB driver for a phone in fastboot mode than it
does for ADB mode, and often can't find one automatically — the device
shows up as "Unknown"/"Android" in Device Manager and `fastboot devices`
returns nothing. The **"Fix: install USB driver"** button downloads Google's
official generic Android USB driver package (`android_winusb.inf`) from
`dl.google.com` and installs it via `pnputil` (you'll get a UAC prompt —
approve it). This only fetches the one official Google-hosted package;
LoveRoot does not download or run any third-party "driver fixer" tools.

Note: this generic driver covers Nexus/Pixel-class devices out of the box
and often works for other brands too, but some vendors (e.g. Xiaomi) ship
their own fastboot driver that's more reliable for their devices. If the
generic driver doesn't fix detection, install your phone maker's official
USB driver instead, then try "Switch to fastboot" again.

## "Fix: generic fastboot driver" (non-Pixel phones, e.g. Xiaomi/Redmi/POCO)

If the Google driver above still doesn't fix detection, this button
installs a driver LoveRoot writes itself (no download) that matches by
**USB interface class** (the fastboot protocol interface, class FF /
subclass 42 / protocol 03) instead of by vendor ID — this is the same
interface every Android phone uses for fastboot regardless of brand, so it
isn't limited to Google/Pixel hardware IDs the way the driver above is.

This driver is **unsigned**. Modern Windows blocks unsigned drivers by
default, so `pnputil` may report a signature error — LoveRoot will show
that error in the log if it happens. If it does, you have two options:
- Temporarily disable **Driver Signature Enforcement**
  (Settings → Recovery → Advanced startup → Troubleshoot → Advanced options
  → Startup Settings → press 7), or
- Use [Zadig](https://zadig.akeo.ie/), a reputable open-source tool that
  does the same interface-class WinUSB binding through a properly signed
  driver.

## Project layout

```
LoveRoot/
├── main.py                       # Tkinter GUI
├── device_manager.py             # adb/fastboot orchestration
├── bootstrap.py                  # auto-downloads adb/fastboot if missing
├── patched_boot_image_HERE/      # <- put your patched boot.img here
├── platform-tools/               # auto-populated on first run (or bring your own)
└── assets/
```

## Running from source

```bash
pip install --upgrade pip   # no extra deps needed, Tkinter is stdlib
python main.py
```

## Building LoveRoot.exe

```bash
pip install pyinstaller
pyinstaller --noconsole --onefile --name LoveRoot main.py
```

The .exe will be in `dist/LoveRoot.exe`. Ship it alongside a `platform-tools/`
folder (containing `adb.exe`/`fastboot.exe`) in the same directory, or require
users to have platform-tools on their PATH.

## Usage flow

1. **Detect device** — finds the phone in ADB or fastboot mode, shows model.
2. **Select patched boot.img** — you pick the file; the tool never guesses.
3. **Flash + Root** — shows a warning describing exactly what will be
   overwritten and requires you to type `CONFIRM` before anything happens.
   Then it reboots to bootloader, runs `fastboot flash boot <file>`, reboots,
   and polls for root via `su -c id`.

## Safety notes

- Always keep a full stock firmware package for your device on hand so you
  can recover via `fastboot flash boot stock_boot.img` if something goes wrong.
- This flashes the `boot` partition only — it doesn't touch `system`,
  `vendor`, `userdata`, or partition tables.
- If `fastboot flash` fails partway, do not disconnect the device; consult
  your device's specific unbrick/EDL recovery procedure.
